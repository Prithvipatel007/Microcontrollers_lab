#include "arm_comm.h"
#include "drv_glcd.h"

#ifndef __HS_LOGO_H
#define __HS_LOGO_H

extern Bmp_t Picture_HS;

#endif // __OLIMEX_LOGO_H