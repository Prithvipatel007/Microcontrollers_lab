
#ifndef __BUTTON_H 
#define __BUTTON_H

#define BUTTON_Left               1
#define BUTTON_Right              2
#define BUTTON_Joystick_Center    3


void BUTTON_Init(unsigned char number);
unsigned char BUTTON_Read(unsigned char number);

#endif