/******************************************************************************
 *   irq.h:  Interrupt related Header file for NXP LPC230x Family
 *   Microprocessors
 *
 *   Copyright(C) 2006, NXP Semiconductor
 *   All rights reserved.
 *
 *   History
 *   2006.09.01  ver 1.00    Prelimnary version, first Release
 *
******************************************************************************/
#ifndef __IRQ_H
#define __IRQ_H

#if 0
#define I_Bit     0x80
#define F_Bit     0x40

#define SYS32Mode   0x1F
#define IRQ32Mode   0x12
#define FIQ32Mode   0x11
#endif

#define HIGHEST_PRIORITY  0x01
#define LOWEST_PRIORITY   0x0F

extern void NVIC_IntEnable(long IntNumber);
extern void NVIC_IntDisable(long IntNumber);
extern void NVIC_ClrPend(long IntNumber);
extern void NVIC_IntPri(long IntNumber,char Priority);

#endif /* end __IRQ_H */

/******************************************************************************
**                            End Of File
******************************************************************************/
