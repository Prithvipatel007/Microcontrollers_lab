#include <nxp/iolpc1766.h>
#include <intrinsics.h>

#define CLK             4000000         // 4 MHz
#define PCLK            (CLK/4)         // 1 MHz

#define TMR0_IRQ        1

void TMR0_Init(void)
{
  __disable_interrupt();
  
  PCONP_bit.PCTIM0 = 1;         // PCLK to timer 0

  T0TCR_bit.CE = 0;             // timer 0 stop
  T0TCR_bit.CR = 1;             // set reset
  T0TCR_bit.CR = 0;             // release reset
  T0CTCR_bit.CTM = 0;           // timer 0 mode: every rising PCLK edge
  T0MCR_bit.MR0I = 1;           // enable irq on MR0
  T0MCR_bit.MR0R = 1;           // enable reset on MR0
  T0MCR_bit.MR0S = 0;           // disable stop on MR0
  
  T0PR = 0;                     // no prescale
  T0MR0 = PCLK/4;               // period =0.25s
  
  T0IR_bit.MR0INT = 1;          // timer 0 irq clear pending
  SETENA0 |= 1<<(TMR0_IRQ);     // timer 0 irq enable (NVIC)
  
  T0TCR_bit.CE = 1;             // timer 0 start
  
  __enable_interrupt();
}

//************************************************************
// blink LED1 at P1_25 by toggle
//************************************************************

void TMR0_IRQHandler(void)
{
  FIO1PIN_bit.P1_25 ^= 1;       // toggle
  
  T0IR_bit.MR0INT = 1;          // timer 0 irq clear pending
  CLRPEND0 |= 1<<(TMR0_IRQ);    // timer 0 irq clear pending (NVIC)
}

int main(void)
{ 
  FIO1DIR_bit.P1_25 = 1;        // output
  TMR0_Init();

  while (1)                     // wait for irq
  {
  }
  return 0;
}
