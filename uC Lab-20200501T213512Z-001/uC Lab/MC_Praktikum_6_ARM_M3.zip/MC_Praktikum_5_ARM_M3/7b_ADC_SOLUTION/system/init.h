void InitClock(void);
void GpioInit(void);
void Dly100us(void *arg);
void reverse(char s[]);
void itoa(int n, char s[]);