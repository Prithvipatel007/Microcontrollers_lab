#include <NXP/iolpc1766.h>
#include "button.h"

void BUTTON_Init(unsigned char number)
{
  switch(number)
  {
    case BUTTON_Left:
    PINSEL1 = PINSEL1 & 0xFFFF3FFF;
    FIO0DIR = FIO0DIR & (~0x00800000);
    FIO0MASK = FIO0MASK & (~0x00800000);
    break;
  
    case BUTTON_Joystick_Center:
    PINSEL4 = PINSEL4 & 0xFFFFFF3F;
    FIO0DIR = FIO0DIR & (~0x00000020);
    FIO0MASK = FIO0MASK & (~0x00000020); 
    break;
  
    case BUTTON_Right:
    PINSEL0 = PINSEL0 & 0xFF3FFFFF;
    FIO2DIR = FIO2DIR & (~0x00002000);
    FIO2MASK = FIO2MASK & (~0x00002000);
    break;
  
    default:
    break;
  }
}

unsigned char BUTTON_Read(unsigned char number)
{
  unsigned long value = 0;
  
  switch(number)
  {
    case BUTTON_Left:
    value = FIO0PIN;
    value = value & 0x00800000;
    value = (value>>23);
    break;
    default:
    break;
  
    case BUTTON_Joystick_Center:
    value = FIO0PIN;
    value = value & 0x00000020;
    value = (value>>5);  
    break;
  
    case BUTTON_Right:
    value = FIO2PIN;
    value = value & 0x00002000;
    value = (value>>13);  
    break;
  }
  return value;
}
