#include "includes.h"
#include "init.h"
#include "adc.h"
#include "button.h"

// globales Array beinhaltet AD-Werte
extern volatile long ADC0Value[];
// globales Flag ob ein neuer Wert eingelesen wurde, muss danach geloescht werden
extern volatile long ADC0IntDone;

void main_print_value(int value)
{
  char output_string[5];
  
  itoa(value, output_string);
  //output_string[4] = '\r';
  
  if (value >= 10)
  {
    if (value >= 100)
    {
      if (value >= 1000)
      {      
      }
      else
      {
        output_string[3] = output_string[2];
        output_string[2] = output_string[1]; 
        output_string[1] = output_string[0];
        output_string[0] = ' '; 
      }
    }
    else
    {
      output_string[3] = output_string[1];
      output_string[2] = output_string[0]; 
      output_string[1] = ' ';
      output_string[0] = ' '; 
    }
  }
  else
  {
    output_string[3] = output_string[0];
    output_string[2] = ' '; 
    output_string[1] = ' ';
    output_string[0] = ' '; 
  }
  GLCD_print(output_string);  
}

// globale Taktfrequenz = 100MHz

int main(void)
{
  // Variable fuer das Einlesen der Schalter
  unsigned char button_data;
  // Variable fuer das Einlesen der ADC-Werte
  unsigned int adc_data;
  // Flag welcher AD-Wert angezeigt wird (Poti == 0, Temperatur == 5)
  unsigned char flag = 0;
  
  // Initialisierungsroutinen fuer Flash, Takt, GPIO, ADC und Buttons
  FLASHCFG = (0x5UL<<12) | 0x3AUL;
  InitClock();
  GpioInit();  
  ADCInit( );
  BUTTON_Init(BUTTON_Left);
  BUTTON_Init(BUTTON_Right);
  
  //enable globale Interrupts
  __enable_interrupt(); 
   
  // wait 1 second
  Dly100us((void*)10000);  
   
  // Display Init
  GLCD_PowerUpInit((pInt8U) Picture_HS.pPicStream);
  GLCD_Backlight(BACKLIGHT_ON);
  extern FontType_t Terminal_9_12_6;
  GLCD_SetFont(&Terminal_9_12_6,0x000F00,0x00FF0);
  GLCD_SetWindow(0,0,131,18);
  GLCD_TextSetPos(0,0);
  GLCD_print("Please wait ...\r");

  // wait 1 second
  Dly100us((void*)30000);   
   
  while(1)
  {  
    button_data = BUTTON_Read(BUTTON_Left);
    if(button_data == 0)
    {
      flag = 0;     
    }

    button_data = BUTTON_Read(BUTTON_Right);
    if(button_data == 0)
    {
      flag = 1;
    }

    if (flag == 0)
    {
      ADC0Read( 5 );
      if (ADC0IntDone == 1)
      {
        // Poti
        adc_data = ADC0Value[5];
        GLCD_print("\r");
        GLCD_print("ADC-Value: ");  
        main_print_value((int)adc_data); 
      }   
    }
    else if (flag == 1)
    {   
      ADC0Read( 1 );
      if (ADC0IntDone == 1)
      {
        signed int val;
        
        // Temperatur
        adc_data = ADC0Value[1];
        val = (((signed int) adc_data) - 535) / 4 + 20;
        GLCD_print("\r");
        GLCD_print("Temp-Value: ");  
        main_print_value((int)val);   
      }
    }    
  }
}
