#include <nxp/iolpc1766.h>

//************************************************************

void Delay(volatile unsigned long i) { while (i!=0) i--; }

//************************************************************
// toggle LED1 at P1_25 by BUTTON1 at P0_23
//************************************************************
int main (void)
{ 
  FIO1DIR_bit.P1_25 = 1;        // output
  
  while (1)
  {
    if (FIO0PIN_bit.P0_23 == 0) // check =0
    {
      FIO1PIN_bit.P1_25 ^= 1;   // toggle
      Delay(1<<18);
    }
  }
  return 0;
}
