#include <nxp/iolpc1766.h>
#include <intrinsics.h>

#define EINT3_IRQ       21

void EINT3_IRQHandler(void)
{
  FIO1PIN_bit.P1_25 ^= 1;       // LED1 toggle
  // FIO0PIN_bit.P0_4 ^= 1;        // LED2 toggle
  
  IO0INTCLR_bit.P0_23 = 1;      // BUTTON1 ext irq clear pending
  CLRPEND0 |= 1<<(EINT3_IRQ);   // ext irq all port pins clear pending (NVIC)
}

void EINT3_Init(void)
{
  __disable_interrupt();
  
  IO0INTENF_bit.P0_23 = 1;      // BUTTON1 ext irq on falling edge (= button press)
  // IO0INTENR_bit.P0_23 = 1;      // BUTTON1 ext irq on rising edge (= button release)
  SETENA0 |= 1<<(EINT3_IRQ);    // ext irq all port pins enable (NVIC)
  
  __enable_interrupt();
}

int main(void)
{ 
  FIO1DIR_bit.P1_25 = 1;        // LED1 output
  // FIO0DIR_bit.P0_4 = 1;         // LED2 output
  FIO1PIN_bit.P1_25 = 1;        // LED1 off
  FIO0PIN_bit.P0_4  = 1;        // LED2 off
  EINT3_Init();

  while (1)                     // wait for irq
  {
  }
  return 0;
}
