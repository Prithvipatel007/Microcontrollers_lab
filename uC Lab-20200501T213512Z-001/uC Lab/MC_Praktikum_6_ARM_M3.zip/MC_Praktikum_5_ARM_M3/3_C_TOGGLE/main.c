#include <nxp/iolpc1766.h>

//************************************************************

void Delay(volatile unsigned long i) { while (i!=0) i--; }

//************************************************************
// blink LED1 at P1_25 by toggle
//************************************************************
int main (void)
{ 
  FIO1DIR_bit.P1_25 = 1;        // output

  while (1)
  {
      FIO1PIN_bit.P1_25 ^= 1;   // toggle
      Delay(1<<18);
  }
  return 0;
}
