#include "EFM8BB1.h"

// long delay
void delay(unsigned int cnt)
{
  while (--cnt);
	while (--cnt);
	while (--cnt);
	while (--cnt);
}

// segments
sbit S0 = P0^0;
sbit S1 = P0^1;
sbit S2 = P0^2;
sbit S3 = P0^3;
sbit S4 = P1^0;
sbit S5 = P1^1;
sbit S6 = P1^2;
// segment dot
sbit S7 = P1^3;

void null(void)
{
	S0 = 0;
	S1 = 0;
	S2 = 0;
	S3 = 0;
	S4 = 0;
	S5 = 0;
	S6 = 1;
}

void one(void)
{
	S0 = 1;
	S1 = 0;
	S2 = 0;
	S3 = 1;
	S4 = 1;
	S5 = 1;
	S6 = 1;
}

void two(void)
{
	S0 = 0;
	S1 = 0;
	S2 = 1;
	S3 = 0;
	S4 = 0;
	S5 = 1;
	S6 = 0;
}

void three(void)
{
	S0 = 0;
	S1 = 0;
	S2 = 0;
	S3 = 0;
	S4 = 1;
	S5 = 1;
	S6 = 0;
}

void main(void)
{
	XBR2 |= 0x40;		// port power
	
	while (1)
  {
		null();
		delay(0xFF);
		one();
		delay(0xFF);
		two();
		delay(0xFF);
		three();
		delay(0xFF);
		S7 = 0;				// blink dot
		delay(0xFF);
		S7 = 1;
		delay(0xFF);
  }
}
