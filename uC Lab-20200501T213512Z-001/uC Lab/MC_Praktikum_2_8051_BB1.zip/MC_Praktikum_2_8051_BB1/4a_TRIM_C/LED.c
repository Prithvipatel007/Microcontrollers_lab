#include "EFM8BB1.h"

// long delay
void delay (unsigned char val)
{
	volatile short idx, cnt;

	for (idx=0; idx<=val; idx++)
		for (cnt=0; cnt<=0x3FFF; cnt++);
}

// segment dot
sbit S7 = P1^3;

// serial send
void send(unsigned char ch)
{
	// add parity to char
	// unsigned char par = ((unsigned char) P) << 7;
	// SBUF = ch | par;

	// no partity
	SBUF = ch;

	while (!TI);	// wait until transmitted
	TI=0;
}

void init(void)
{
	// EFM8 specific serial configuration
	// P0.4 - UART0 TX - PUSH_PULL
	// P0.5 - UART0 RX - OPEN_DRAIN
	P0MDOUT |= (1 << (4));

	// EFM8 specific ADC configuration
	// P0.7 - ADC0
	P0MDIN &= ~(1 << (7));	// set P0.7 to analog input
	P0SKIP |= (1 << (7));		// disconnect P0.7 from digital
	ADC0MX = 7;							// connect P0.7 to ADC0 via MUX
	// ADC0 configuration - %00001|1|0|1 - SYSCLK/(1+1)|8-bit mode|no delay|gain=1
	ADC0CF = 0x0D;
	REF0CN = 0x08;					// voltage reference is VDD=3.3V
	ADC0CN0 |= (1 << (7));	// enable ADC0

	// SYSCLK = HFOSC0 = 24.5 MHz
	// SYSCLK = SYSCLK/1
	CLKSEL = 0;
	// timer 1 uses SYSCLK
	CKCON0 |= (1 << (3));

	XBR0 |= (1 << (0));	// cross-bar enable UART0 pins
	XBR2 |= (1 << (6));	// cross-bar enable all pins

	// 8051 serial configuration
	// UART mode %01 = 8-bit data
	SCON = 0x40;
	// timer 1 mode 2
	TMOD = 0x20;
	// Baud rate
	TH1 = 0x96;	// 256-150=106 - 24.5 MHz / 106 = 231132 / 2 = 115566 (115200 Baud 0.3% error)
	TL1 = 0x96;
	// timer 1 start
	TR1 = 1;
}

void main(void)
{
	unsigned short counter = 0;
	char ch, buffer[] = "-----";	// 4 decimal digits + CR terminal new line
	buffer[4] = 0x0D;							// CR terminal new line

	init();

	while (1)
	{
		unsigned char idx = 0;

		// ADC0 conversion
		ADC0CN0 |= (1 << (4));					// start conversion
		while ((ADC0CN0 & 0x10) == 0);	// wait for done
		ADC0CN0 &= ~(1 << (5));					// reset

		// CAUTION: 8-bit result is bits 9:2
		counter = ((ADC0H << 8) | ADC0L);
		counter >>= 2;		// 8-bit result

		// convert to ASCII
		buffer[0] = 0x30 + counter/1000;
		buffer[1] = 0x30 + (counter%1000)/100;
		buffer[2] = 0x30 + (counter%100)/10;
		buffer[3] = 0x30 + counter%10;

		while ((ch = buffer[idx++]) != 0)
			send(ch);

		// blink dot
		S7 ^= 1;

		delay(25);
	}
}
