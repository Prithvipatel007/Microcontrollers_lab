#include "EFM8BB1.h"

// long delay
void delay(unsigned int cnt)
{
  while (--cnt);
	while (--cnt);
	while (--cnt);
	while (--cnt);
}

// segment numbers
// 0 : %1100|0000
// 1 : %1111|1001
code unsigned char seg[] = {0xC0, 0xF9};

// segment dot
sbit DOT = P1^3;

void seg_write(unsigned char val)
{
	unsigned char high, low;
	
	P0 |= 0x0F;											// clear low nibble
	P1 |= 0x0F;											// clear high nibble
	
	low = 0x0F & seg[val];					// get low nibble from array
	high = (0xF0 & seg[val]) >> 4;	// get high nibble from array
	
	P0 &= (0xF0 | low);							// write low nibble
	P1 &= (0xF0 | high);						// write high nibble
}

void main(void)
{
	XBR2 |= 0x40;		// port power
	
	while (1)
  {
		unsigned char idx;
		
		for (idx=0; idx<=1; idx++)
		{
			seg_write(idx);
			delay(0xFF);
		}
		DOT = 0;				// blink dot
		delay(0xFF);
		DOT = 1;
		delay(0xFF);
  }
}
