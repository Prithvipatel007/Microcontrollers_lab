#include "lpc810.h"

#define CLK     12000000                // CLK 12 MHz

#define DELAY   (CLK/1000)*500          // MRT 0.5s

void init(void)
{
  // MRT channel 0
  SYSAHBCLKCTRL_bit.MRT = 1;            // MRT clock enable
  PRESETCTRL_bit.MRT_RESET_LOW = 0;     // MRT reset
  PRESETCTRL_bit.MRT_RESET_LOW = 1;
  
  MRTCTRL0_bit.MODE = 1;                // MRT single mode
  MRTINTVAL0_bit.IVALUE = DELAY;        // MRT start
  
  // LED on P0_4
  DIR0_bit.P0_4 = 1;                    // P0_4 set to output
  
  PIN0_bit.P0_4 = 1;                    // P0_4 set to high (LED off)
}

/* CAUTION: for polling MRT repeated mode and checking        */
/* if (MRTTIMER0_bit.VALUE == 0)                              */
/* does not work since MRT is too fast and some 0 are skipped */

void main(void)
{
  init();
  
  while (1)
  {
    // MRT channel 0
    if (MRTSTAT0_bit.RUN == 0)          // MRT has stopped ?
    {
      PIN0_bit.P0_4 ^= 1;               // P0_4 toggle
      MRTINTVAL0_bit.IVALUE = DELAY;    // MRT re-start
    }
  }
}
