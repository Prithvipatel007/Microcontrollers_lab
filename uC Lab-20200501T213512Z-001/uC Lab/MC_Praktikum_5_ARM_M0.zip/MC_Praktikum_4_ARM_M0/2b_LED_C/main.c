#include "lpc810.h"

void delay(volatile unsigned long cycles)
{
  while (cycles) {cycles--;}
}

void init(void)
{
  // LED on P0_4
  
  // P0_4 digital is default
  // no setting required
  
  // P0_4 set to output
  DIR0_bit.P0_4 = 1;
  
  // P0_4 set to high (LED off)
  PIN0_bit.P0_4 = 1;
  
  // LED on P0_2
  
  // P0_2 digital is NOT default
  PINENABLE0_bit.SWDIO_DISABLE = 1;
  
  // P0_2 set to output
  DIR0_bit.P0_2 = 1;
  
  // P0_2 set to low (LED on)
  PIN0_bit.P0_2 = 0;
}

void main(void)
{
  init();
  
  while (1)
  { 
    // P0_4 toggle and P0_2 toggle
    PIN0_bit.P0_4 ^= 1;
    PIN0_bit.P0_2 ^= 1;
    
    delay(500000);
  }
}
