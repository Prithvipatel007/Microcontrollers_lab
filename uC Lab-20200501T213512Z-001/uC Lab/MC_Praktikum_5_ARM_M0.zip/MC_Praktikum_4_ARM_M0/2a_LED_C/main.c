#include "lpc810.h"

void delay(volatile unsigned long cycles)
{
  while (cycles) {cycles--;}
}

void init(void)
{
  // LED on P0_4
  
  // P0_4 digital is default
  // no setting required
  
  // P0_4 set to output
  DIR0_bit.P0_4 = 1;
  
  // P0_4 set to high (LED off)
  PIN0_bit.P0_4 = 1;
}

void main(void)
{
  init();
  
  while (1)
  {
    // P0_4 toggle
    PIN0_bit.P0_4 ^= 1;
    
    delay(500000);
  }
}
