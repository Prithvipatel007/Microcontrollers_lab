#include "io_macros.h"

// Pin functions

typedef struct {
  __REG32 U0_TXD   : 8;
  __REG32 U0_RXD   : 8;
  __REG32          :16;
} __pinassign_bits;

__IO_REG32_BIT(PINASSIGN0, 0x4000C000, __READ_WRITE,  __pinassign_bits);

typedef struct {
  __REG32 ACMP_I1_DISABLE   : 1;
  __REG32 ACMP_I2_DISABLE   : 1;
  __REG32 SWCLK_DISABLE     : 1;
  __REG32 SWDIO_DISABLE     : 1;
  __REG32                   :28;
} __pinenable_bits;

__IO_REG32_BIT(PINENABLE0, 0x4000C1C0, __READ_WRITE, __pinenable_bits);

// Power and clock

typedef struct {
  __REG32 SPI0_RESET_LOW      : 1;
  __REG32 SPI1_RESET_LOW      : 1;
  __REG32 UARTFRG_RESET_LOW   : 1;
  __REG32 UART0_RESET_LOW     : 1;
  __REG32 UART1_RESET_LOW     : 1;
  __REG32 UART2_RESET_LOW     : 1;
  __REG32 I2C_RESET_LOW       : 1;
  __REG32 MRT_RESET_LOW       : 1;
  __REG32 SCT_RESET_LOW       : 1;
  __REG32 WKT_RESET_LOW       : 1;
  __REG32 GPIO_RESET_LOW      : 1;
  __REG32 FLASH_RESET_LOW     : 1;
  __REG32 ACMP_RESET_LOW      : 1;
  __REG32                     :19;
} __presetctrl_bits;

__IO_REG32_BIT(PRESETCTRL, 0x40048004, __READ_WRITE, __presetctrl_bits);

typedef struct {
  __REG32 IRCOUT_DISABLE   : 1;
  __REG32 IRC_DISABLE      : 1;
  __REG32 FLASH_DISABLE    : 1;
  __REG32 BOD_DISABLE      : 1;
  __REG32 UNDEFINED_4      : 1;
  __REG32 SYSOSC_DISABLE   : 1;
  __REG32 WDTOSC_DISABLE   : 1;
  __REG32 SYSPLL_DISABLE   : 1;
  __REG32 UNDEFINED_8      : 4;
  __REG32 UNDEFINED_12     : 3;
  __REG32 ACMP_DISABLE     : 1;
  __REG32                  :16;
} __pdruncfg_bits;

__IO_REG32_BIT(PDRUNCFG, 0x40048238, __READ_WRITE, __pdruncfg_bits);

typedef struct {
  __REG32 SYS        : 1;
  __REG32 ROM        : 1;
  __REG32 RAM        : 1;
  __REG32 FLASHREG   : 1;
  __REG32 FLASH      : 1;
  __REG32 I2C        : 1;
  __REG32 GPIO       : 1;
  __REG32 SWM        : 1;
  __REG32 SCT        : 1;
  __REG32 WKT        : 1;
  __REG32 MRT        : 1;
  __REG32 SPI0       : 1;
  __REG32 SPI1       : 1;
  __REG32 CRC        : 1;
  __REG32 UART0      : 1;
  __REG32 UART1      : 1;
  __REG32 UART2      : 1;
  __REG32 WWDT       : 1;
  __REG32 IOCON      : 1;
  __REG32 ACMP       : 1;
  __REG32            :12;
} __sysahbclkctrl_bits;

__IO_REG32_BIT(SYSAHBCLKCTRL, 0x40048080, __READ_WRITE, __sysahbclkctrl_bits);

// Comparator

typedef struct {
  __REG32 UNDEFINED_0    : 3;
  __REG32 EDGESEL        : 2;
  __REG32 UNDEFINED_5    : 1;
  __REG32 COMPSA         : 1;
  __REG32 UNDEFINED_7    : 1;
  __REG32 COMP_VP_SEL    : 3;
  __REG32 COMP_VM_SEL    : 3;
  __REG32 UNDEFINED_14   : 6;
  __REG32 EDGECLR        : 1;
  __REG32 COMPSTAT       : 1;
  __REG32                :10;
} __compctrl_bits;

__IO_REG32_BIT(COMPCTRL, 0x40024000, __READ_WRITE,  __compctrl_bits);

typedef struct {
  __REG32 LADEN    : 1;
  __REG32 LADSEL   : 5;
  __REG32 LADREF   : 1;
  __REG32          :25;
} __complad_bits;

__IO_REG32_BIT(COMPLAD, 0x40024004, __READ_WRITE,  __complad_bits);

// UART

typedef struct {
  __REG32 DIV   : 8;
  __REG32       :24;
} __uartclkdiv_bits;

__IO_REG32_BIT(UARTCLKDIV, 0x40048094, __READ_WRITE,  __uartclkdiv_bits);

typedef struct {
  __REG32 DIV   : 8;
  __REG32       :24;
} __uartfrgdiv_bits;

__IO_REG32_BIT(UARTFRGDIV, 0x400480F0, __READ_WRITE,  __uartclkdiv_bits);

typedef struct {
  __REG32 MULT   : 8;
  __REG32        :24;
} __uartfrgmult_bits;

__IO_REG32_BIT(UARTFRGMULT, 0x400480F4, __READ_WRITE,  __uartfrgmult_bits);

typedef struct {
  __REG32 ENABLE        : 1;
  __REG32 UNDEFINED_1   : 1;
  __REG32 DATALEN       : 2;
  __REG32 PARITYSEL     : 2;
  __REG32 STOPLEN       : 1;
  __REG32               :25;
} __uartcfg_bits;

__IO_REG32_BIT(UARTCFG, 0x40064000, __READ_WRITE, __uartcfg_bits);

typedef struct {
  __REG32 RXRDY         : 1;
  __REG32 RXIDLE        : 1;
  __REG32 TXRDY         : 1;
  __REG32 TXIDLE        : 1;
  __REG32 CTS           : 1;
  __REG32 DELTACTS      : 1;
  __REG32 TXDISINT      : 1;
  __REG32 UNDEFINED_7   : 1;
  __REG32 OVERRUNINT    : 1;
  __REG32 UNDEFINED_9   : 1;
  __REG32 RXBRK         : 1;
  __REG32 DELTARXBRK    : 1;
  __REG32               :20;
} __uartstat_bits;

__IO_REG32_BIT(UARTSTAT, 0x40064008, __READ_WRITE, __uartstat_bits);

typedef struct {
  __REG32 TXDAT   : 8;
  __REG32         :24;
} __txdat_bits;

__IO_REG32_BIT(UARTTXDAT, 0x4006401C, __READ_WRITE,  __txdat_bits);

typedef struct {
  __REG32 BRGVAL   :16;
  __REG32          :16;
} __uartbrg_bits;

__IO_REG32_BIT(UARTBRG, 0x40064020, __READ_WRITE,  __uartbrg_bits);

// GPIO

typedef struct {
    __REG32 UNDEFINED_0   : 3;
    __REG32 MODE          : 2;
    __REG32               :27;
} __pio0_bits;

__IO_REG32_BIT(PIO0_0, 0x40044044, __READ_WRITE, __pio0_bits);

typedef struct {
    __REG32 P0_0   : 1;
    __REG32 P0_1   : 1;
    __REG32 P0_2   : 1;
    __REG32 P0_3   : 1;
    __REG32 P0_4   : 1;
    __REG32 P0_5   : 1;
    __REG32        :26;
} __gpio0_bits;

__IO_REG32_BIT(DIR0, 0xA0002000, __READ_WRITE, __gpio0_bits);
__IO_REG32_BIT(PIN0, 0xA0002100, __READ_WRITE, __gpio0_bits);

#define PIN0BASE        0xA0000000

__IO_REG8(P0_0, PIN0BASE    , __READ_WRITE);
__IO_REG8(P0_1, PIN0BASE + 1, __READ_WRITE);
__IO_REG8(P0_2, PIN0BASE + 2, __READ_WRITE);
__IO_REG8(P0_3, PIN0BASE + 3, __READ_WRITE);
__IO_REG8(P0_4, PIN0BASE + 4, __READ_WRITE);
__IO_REG8(P0_5, PIN0BASE + 5, __READ_WRITE);
