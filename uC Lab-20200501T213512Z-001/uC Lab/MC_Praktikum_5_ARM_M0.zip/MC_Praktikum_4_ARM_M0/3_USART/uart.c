#include "lpc810.h"

void uart0Init(unsigned long baudRate, unsigned long clk)
{
  unsigned long sclk, brgval;
  const unsigned long div = 1, frgdiv = 0xFF;

  // Setup clock and reset USART0
  UARTCLKDIV_bit.DIV = div;
  SYSAHBCLKCTRL_bit.UART0 = 1;          // USART0 power
  PRESETCTRL_bit.UART0_RESET_LOW = 0;   // USART0 reset
  PRESETCTRL_bit.UART0_RESET_LOW = 1;
  
  // Configure USART0
  sclk = clk/div;
  UARTCFG_bit.DATALEN = 1;
  UARTCFG_bit.PARITYSEL = 0;
  UARTCFG_bit.STOPLEN = 0;
  
  brgval = sclk / 16 / baudRate - 1;
  UARTBRG_bit.BRGVAL = brgval;          // baud rate generator value
  UARTFRGDIV_bit.DIV = frgdiv;          // baud rate generator divider
  UARTFRGMULT_bit.MULT = (((sclk / 16) * (frgdiv + 1)) / (baudRate * (brgval + 1))) - (frgdiv + 1);
  
  // Clear status bits
  UARTSTAT_bit.DELTACTS = 1;
  UARTSTAT_bit.DELTARXBRK = 1;

  // Start USART0
  UARTCFG_bit.ENABLE = 1;
}

void uart0SendChar(char buffer)
{
  // Wait until ready to send
  while (!(UARTSTAT_bit.TXRDY));
  
  UARTTXDAT_bit.TXDAT = buffer;
}
