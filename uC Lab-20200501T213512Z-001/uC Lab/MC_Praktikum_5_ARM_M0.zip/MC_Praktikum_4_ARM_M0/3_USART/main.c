#include "lpc810.h"

extern void uart0Init(unsigned long, unsigned long);
extern void uart0SendChar(char);

void delay(volatile unsigned long cycles)
{
  while (cycles) {cycles--;}
}

#define CLK             12000000        // internal oszillator
#define BAUD            4800            // UART baud rate
// #define BAUD            115200          // UART baud rate

void init(void)
{
  // LED on P0_2
  
  // P0_2 digital is NOT default
  PINENABLE0_bit.SWDIO_DISABLE = 1;
  
  // P0_2 set to output
  DIR0_bit.P0_2 = 1;
  
  // P0_2 set to low (LED on)
  PIN0_bit.P0_2 = 0;
  
  // P0_4 as U0_TXD and P0_0 as U0_RXD (same as ISP bootloader)
  PINASSIGN0_bit.U0_TXD = 4;
  PINASSIGN0_bit.U0_RXD = 0;
  
  // UART0 init
  uart0Init(BAUD, CLK);
}

void main(void)
{
  unsigned int counter = 0;
  char ch, buffer[] = "-----";  // 4 decimal digits + CR terminal new line
  buffer[4] = 0x0D;             // CR terminal new line
  
  init();
  
  while (1)
  { 
    // P0_2 toggle
    PIN0_bit.P0_2 ^= 1;
    
    // counter 4 decimal digits
    if (counter++ > 9999)
      counter = 0;
    
    // convert to ASCII
    buffer[0] = 0x30 + counter/1000;
    buffer[1] = 0x30 + (counter%1000)/100;
    buffer[2] = 0x30 + (counter%100)/10;
    buffer[3] = 0x30 + counter%10;
    
    unsigned int idx = 0;
    while ((ch = buffer[idx++]) != 0)
      uart0SendChar(ch);
    
    delay(500000);
  }
}
