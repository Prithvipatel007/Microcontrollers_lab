#include "lpc810.h"

void delay(volatile unsigned long cycles)
{
  while (cycles) {cycles--;}
}

void COMP_init(unsigned char threshold)
{
  // LED on P0_4
  DIR0_bit.P0_4 = 1;    // P0_4 set to output
  PIN0_bit.P0_4 = 1;    // P0_4 set to high (LED off)
  
  SYSAHBCLKCTRL_bit.IOCON = 1;          // PIO CLK on
  SYSAHBCLKCTRL_bit.ACMP = 1;           // COMP CLK on
  PDRUNCFG_bit.ACMP_DISABLE = 0;        // COMP power on
  
  PRESETCTRL_bit.ACMP_RESET_LOW = 0;    // COMP reset 0 -> 1
  PRESETCTRL_bit.ACMP_RESET_LOW = 1;
  
  // P0.0 -> ACMP1
  PIO0_0_bit.MODE = 0;                  // no internal pull resistors
  PINENABLE0_bit.ACMP_I1_DISABLE = 0;   // enable ACMP1
  
  // COMP voltage ladder
  COMPLAD_bit.LADSEL = threshold;       // COMP ladder value
  COMPLAD_bit.LADEN = 1;                // COMP ladder enable
  
  // COMP upper limit (COMP_VP)
  COMPCTRL_bit.COMP_VP_SEL = 1;         // VP=ACMP1
  // COMP lower limit (COMP_VM)
  COMPCTRL_bit.COMP_VM_SEL = 0;         // VM=ladder
}

#define VOLTMAX 31              // 31=VDD=3.3V
#define DELAY   750000

void main(void)
{
  COMP_init(VOLTMAX);           // 31=VDD=3.3V
  
  while (1)
  {
    unsigned char n;
    unsigned int d = 1;
    
    // check voltage from 3.3V to 0V
    for (n=VOLTMAX; n>0; n--)
    {
      // COMP voltage ladder value change
      COMPLAD_bit.LADSEL = n;
      
      // COMP sees current voltage ?
      if (COMPCTRL_bit.COMPSTAT)
      {
        d = n;
        break;
      }
    }
    
    // LED toggle
    PIN0_bit.P0_4 ^= 1;
    
    // 3.3V fast and 0V slow
    delay((unsigned int) (DELAY/d));
  }
}
