#include "lpc810.h"

#define CLK     12000000                // CLK 12 MHz

#define DELAY   (CLK/1000)*500          // MRT 0.5s

void MRT_IRQHandler(void)
{
  if (MRTSTAT0_bit.INTFLAG)             // MRT channel 0
  {
    PIN0_bit.P0_4 ^= 1;                 // P0_4 toggle
    MRTSTAT0_bit.INTFLAG = 1;           // CAUTION: =1 clears interrupt flag
  }
}

void init(void)
{
  // MRT channel 0
  SYSAHBCLKCTRL_bit.MRT = 1;            // MRT clock enable
  PRESETCTRL_bit.MRT_RESET_LOW = 0;     // MRT reset
  PRESETCTRL_bit.MRT_RESET_LOW = 1;
  
  MRTCTRL0_bit.MODE = 0;                // MRT repeated mode
  MRTCTRL0_bit.INTEN = 1;               // MRT irq enable
  
  NVICISER0_bit.ISE_MRT = 1;            // NVIC MRT irq enable
  
  MRTINTVAL0_bit.IVALUE = DELAY;        // MRT start
  
  // LED on P0_4
  DIR0_bit.P0_4 = 1;                    // P0_4 set to output
  
  PIN0_bit.P0_4 = 1;                    // P0_4 set to high (LED off)
}

void main(void)
{
  init();
  
  while (1);
}
