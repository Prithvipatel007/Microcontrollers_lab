#include "lpc810.h"

void COMP_init(unsigned char threshold)
{
  // LED on P0_4
  DIR0_bit.P0_4 = 1;    // P0_4 set to output
  PIN0_bit.P0_4 = 1;    // P0_4 set to high (LED off)
  
  SYSAHBCLKCTRL_bit.IOCON = 1;          // PIO CLK on
  SYSAHBCLKCTRL_bit.ACMP = 1;           // COMP CLK on
  PDRUNCFG_bit.ACMP_DISABLE = 0;        // COMP power on
  
  PRESETCTRL_bit.ACMP_RESET_LOW = 0;    // COMP reset 0 -> 1
  PRESETCTRL_bit.ACMP_RESET_LOW = 1;
  
  // P0.0 -> ACMP1
  PIO0_0_bit.MODE = 0;                  // no internal pull resistors
  PINENABLE0_bit.ACMP_I1_DISABLE = 0;   // enable ACMP1
  
  // COMP voltage ladder
  COMPLAD_bit.LADSEL = threshold;       // COMP ladder value
  COMPLAD_bit.LADEN = 1;                // COMP ladder enable
  
  // COMP upper limit (COMP_VP)
  COMPCTRL_bit.COMP_VP_SEL = 1;         // VP=ACMP1
  // COMP lower limit (COMP_VM)
  COMPCTRL_bit.COMP_VM_SEL = 0;         // VM=ladder
}

#define VOLTMAX 31              // 31=VDD=3.3V

void main(void)
{
  COMP_init(VOLTMAX/2);         // trigger at 3.3V/2=1.65V !
  
  while (1)
  {
    // COMP <> threshold ?
    if (COMPCTRL_bit.COMPSTAT)
      PIN0_bit.P0_4 = 0;        // LED on
    else
      PIN0_bit.P0_4 = 1;        // LED off
  }
}
