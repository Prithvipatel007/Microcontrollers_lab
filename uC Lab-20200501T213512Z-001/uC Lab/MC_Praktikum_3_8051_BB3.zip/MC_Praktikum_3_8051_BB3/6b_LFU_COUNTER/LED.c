#include <REG51.h>
#include "EFM8BB3.h"

bit toggle = 0;
unsigned short freq = 0;

void delay(unsigned int cnt)
{
  while (--cnt);
	while (--cnt);
	while (--cnt);
	while (--cnt);
}

void timer1(void) interrupt 1 using 3
{
	// reload timer 0 with 10 ms
	TL0 = 0xDD;
	TH0 = 0x6F;

	toggle = ~toggle;

	if (!toggle)
	{
		TR1 = 0;									// stop count
		freq = (TH1 << 8) + TL1;
		TL1 = TH1 = 0;						// clear timer 1
	}
	else
		TR1 = 1;	// next count
}

void init(void)
{
	XBR2 |= (1 << (6));	// port power
	
	// T1 : skip to move to T1=P2.3
	P0SKIP = 0xFF;	// %1111|1111
	P1SKIP = 0xFF;	// %1111|1111
	P2SKIP = 0x07;	// %0000|0111
	
	// timer0 mode1 and timer1 mode1 freq: %0101|0001
	TMOD = 0x51;

	// load timer 0 with 10 ms
	TL0 = 0xDD;
	TH0 = 0x6F;
	TF0 = 0;			// timer 0 reset
	
	IE |= (1 << (1));		// enable timer 0 IRQ
	IE |= (1 << (7));		// enable global
	TR0 = 1;						// timer 0 start
}

void main(void)
{
  init();
  
  while (1)
  {
		// display LEDs : max = 400
		P1 = 0xFF;
		P1 &= ~(1 << (0));
		if (freq > 50)
			P1 &= ~(1 << (1));
		if (freq > 100)
			P1 &= ~(1 << (2));
		if (freq > 150)
			P1 &= ~(1 << (3));
		if (freq > 200)
			P1 &= ~(1 << (4));
		if (freq > 250)
			P1 &= ~(1 << (5));
		if (freq > 300)
			P1 &= ~(1 << (6));
		if (freq > 350)
			P1 &= ~(1 << (7));
    
    delay(200);
  }
}
