#include <REG51.h>
#include "EFM8BB3.h"

void delay(unsigned int cnt)
{
  while (--cnt);
	while (--cnt);
	while (--cnt);
	while (--cnt);
}

// serial send
void send(unsigned char ch)
{
	// add parity to char
	// unsigned char par = ((unsigned char) P) << 7;
	// SBUF = ch | par;

	// no partity
	SBUF = ch;

	while (!TI);	// wait until transmitted
	TI=0;
}

void init(void)
{
	// SYSCLK = HFOSC0 = 24.5 MHz
	// SYSCLK = SYSCLK / 1
	CLKSEL = 0;
	// Timer 0/1 prescale SYSCLK / 4
	CKCON0 = 1;
	
	// UART and Timer 1
	// P0.4 - UART0 TX - PUSH_PULL (not needed here because of status LED)
	// P0.5 - UART0 RX - OPEN_DRAIN
	// P0MDOUT |= (1 << (4));
	
	// UART mode %01 = 8-bit data
	SCON = 0x40;
	// Timer 1 mode 2
	TMOD |= 0x20;
	// Baud rate with prescale SYSCLK / 4
	TH1 = -160;	// 24.5 MHz / 4 / 160 = 38281 / 2 = 19141 (19200 Baud 0.3% error)
	TL1 = -160;
	// Timer 1 start
	TR1 = 1;

	XBR0 |= (1 << (0));		// cross-bar enable UART0 pins
	XBR2 |= (1 << (6));		// cross-bar enable all pins
	WDTCN = 0xDE; WDTCN = 0xAD;		// disable watchdog passcode
}

sbit LED = P1^0;

void main(void)
{
	unsigned short counter = 0;
	char ch, buffer[] = "-----";	// 4 decimal digits + CR terminal new line
	buffer[4] = 0x0D;							// CR terminal new line

	init();

	while (1)
	{
		unsigned char idx = 0;

		// toggle LED
		LED ^= 1;

		// counter 4 decimal digits
		if (counter++ > 9999)
			counter = 0;

		// convert to ASCII
		buffer[0] = 0x30 + counter/1000;
		buffer[1] = 0x30 + (counter%1000)/100;
		buffer[2] = 0x30 + (counter%100)/10;
		buffer[3] = 0x30 + counter%10;

		while ((ch = buffer[idx++]) != 0)
			send(ch);

		delay(200);
	}
}
