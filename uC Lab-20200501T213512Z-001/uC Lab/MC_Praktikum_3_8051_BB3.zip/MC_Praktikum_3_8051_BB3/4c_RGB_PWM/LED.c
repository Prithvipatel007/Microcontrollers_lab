#include <REG51.h>
#include <intrins.h>
#include "EFM8BB3.h"

#define LED_R		1		// LED_R on P3.1
#define LED_G		0		// LED_G on P3.0
#define LED_B		2		// LED_B on P3.2

bit toggle = 0;

// short delay
void delay(void)
{
	_nop_();
	_nop_();
	_nop_();
	_nop_();
}

// BUT on INT1=P0.6
void extint1(void) interrupt 2 using 3
{
	toggle = ~toggle;
}

void init(void)
{
	XBR2 |= (1 << (6));		// port power

	// EFM8 specific irq configuration
	// IRQ assign 6:4 INT1=P0.6 2:0 INT0 not assigned
	IT01CF |= (6 << (4));

	// 8051 standard irq configuration
	TCON |= (1 <<(2));	// enable INT1 edge
	IE |= (1 << (2));		// enable INT1 IRQ
	IE |= (1 << (7));		// enable global
}

void main(void)
{
	init();
	
	// LEDs on : white
	P3 &= ~(1 << (LED_R)); P3 &= ~(1 << (LED_G)); P3 &= ~(1 << (LED_B));
	
  while (1)
  {
		// PWM 20%
		if (! toggle)
		{
			// LEDs on : white
			P3 &= ~(1 << (LED_R)); P3 &= ~(1 << (LED_G)); P3 &= ~(1 << (LED_B));
			delay();
			// LEDs off
			P3 |= (1 << (LED_R)); P3 |= (1 << (LED_G)); P3 |= (1 << (LED_B));
			delay(); delay(); delay(); delay();
		}
		else
		// PWM 80%
		{
			// LEDs on : white
			P3 &= ~(1 << (LED_R)); P3 &= ~(1 << (LED_G)); P3 &= ~(1 << (LED_B));
			delay(); delay(); delay(); delay();
			// LEDs (high)
			P3 |= (1 << (LED_R)); P3 |= (1 << (LED_G)); P3 |= (1 << (LED_B));
			delay();
		}
  }
}
