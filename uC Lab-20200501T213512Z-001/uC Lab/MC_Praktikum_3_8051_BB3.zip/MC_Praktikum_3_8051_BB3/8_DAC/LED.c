#include <REG51.h>
#include "EFM8BB3.h"

// short delay
void delay(void)
{
	volatile unsigned short counter;
	for (counter=0; counter<4000; counter++);
}

void init(void)
{
	// SYSCLK = HFOSC0 = 24.5 MHz
	// SYSCLK = SYSCLK / 1
	CLKSEL = 0;
	
	XBR2 |= (1 << (6));		// port power
	
	SFRPAGE = 0x30;
	DAC0CF0 |= (1 << 7);	// enable DAC0 on P3.0
	DAC1CF0 |= (1 << 7);	// enable DAC1 on P3.1
	SFRPAGE = 0x00;
}

#define DAC0_write(val) {SFRPAGE=0x30; DAC0L=((val)&0x00FF); DAC0H=((val)&0xFF00)>>8; SFRPAGE=0x00;}

#define DAC1_write(val) {SFRPAGE=0x30; DAC1L=((val)&0x00FF); DAC1H=((val)&0xFF00)>>8; SFRPAGE=0x00;}

sbit LED = P1^0;

void main(void)
{
	init();
	
	while (1)
	{
		short val;
		
		LED = 0;
		for (val=0x0FFF; val>0; val--)	// DACs 12-bit down : LEDs on
		{
			DAC1_write(val);	// LED_R
			DAC0_write(val);	// LED_G
			delay();
		}
		LED = 1;
		for (val=0; val<0x0FFF; val++)	// DACs 12-bit up : LEDs off
		{
			DAC1_write(val);
			DAC0_write(val);
			delay();
		}
	}
}
