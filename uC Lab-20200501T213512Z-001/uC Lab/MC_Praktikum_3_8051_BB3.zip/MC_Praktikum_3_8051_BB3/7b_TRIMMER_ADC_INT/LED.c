#include <REG51.h>
#include "EFM8BB3.h"

void delay(unsigned short cnt)
{
	while (--cnt)
	{
		volatile unsigned short idx;
		for (idx=0; idx<1000; idx++);
	}
}

void adc0(void) interrupt 10 using 3
{
	unsigned short counter;

	ADC0CN0 &= ~(1 << (5));		// clear ADC0 irq
	
	counter = (ADC0H << 8) | ADC0L;	// 12-bit
	counter = counter >> 4;					// to 8-bit

	// display LEDs : max = 255
	P1 = 0xFF;
	P1 &= ~(1 << (0));
	if (counter > 35)
		P1 &= ~(1 << (1));
	if (counter > 70)
		P1 &= ~(1 << (2));
	if (counter > 105)
		P1 &= ~(1 << (3));
	if (counter > 140)
		P1 &= ~(1 << (4));
	if (counter > 175)
		P1 &= ~(1 << (5));
	if (counter > 210)
		P1 &= ~(1 << (6));
	if (counter > 245)
		P1 &= ~(1 << (7));

   delay(50);

   ADC0CN0 |= (1<<4);		// start next conversion and wait for irq
}

void init(void)
{
	// SYSCLK = HFOSC0 = 24.5 MHz
	// SYSCLK = SYSCLK / 1
	CLKSEL = 0;

	// cross-bar enable all pins
	XBR2 |= (1 << (6));

	ADC0MX = 5;							// P0.7/ADC5
	ADC0CN1 = (1 << (6));		// ADC0 12-bit
	ADC0CF0 = (0x1 << (3));	// SYSCLK / (1 + 1)
	ADC0CF2 = (1 << (5));		// ADC0 voltage reference is VDD pin
	ADC0CN0 |= (1 << (7));	// ADC0 enable

	EIE1 |= (1 << (3));			// enable ADC0 irq
	IE |= (1 << (7));				// enable global irq
}

void main (void)
{
   init();

   ADC0CN0 |= (1 << (4));	// start first conversion and wait for irq
   while (1);
}
