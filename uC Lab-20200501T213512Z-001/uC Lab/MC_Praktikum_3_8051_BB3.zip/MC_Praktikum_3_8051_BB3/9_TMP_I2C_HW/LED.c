#include <REG51.h>
#include "I2C/I2C_0_CONFIG.h"
#include "EFM8BB3.h"

void delay(unsigned short cnt)
{
	while (--cnt)
	{
		volatile unsigned short idx;
		for (idx=0; idx<1000; idx++);
	}
}

// serial send
void send(unsigned char ch)
{
	// add parity to char
	// unsigned char par = ((unsigned char) P) << 7;
	// SBUF = ch | par;

	// no partity
	SBUF = ch;

	while (!TI);	// wait until transmitted
	TI=0;
}

// UART0 + Timer 1
void init_uart0(void)
{
	// UART mode %01 = 8-bit data
	SCON = 0x40;
	// Timer 1 mode 2
	TMOD |= 0x20;
	// Baud rate with prescale /4
	TH1 = -160;	// 24.5 MHz / 4 / 160 = 38281 / 2 = 19141 (19200 Baud 0.3% error)
	TL1 = -160;
	// Timer 1 start
	TR1 = 1;
	
	// UART0 - reserve TX=P0.4 and RX=P0.5
	P0SKIP = 0xCF;	// %1100|1111
	// cross-bar enable UART0 pins
	XBR0 |= (1 << (0));
}

// I2C0 + Timer 0
void init_i2c0(void)
{
	I2C0_disconnect();
	
	// Timer 0 mode 2
	TMOD |= 0x02;
	// Baud rate
	TH0 = -204;	// 24.5 MHz / 4 / 204 = 30 kHz / 2 = 15 kHz - measured 10 kHz
	TL0 = -204;
	// Timer 0 start
	TR0 = 1;
	
	I2C0_timeout();
	
	// I2C0 - skip P1 to move to SDA=P2.0 and SCL=P2.1
	P1SKIP = 0xFF;
	// cross-bar enable I2C0 pins
	XBR0 |= (1 << (2));
	
	IE |= (1 << (7));			// enable global irq

	I2C0_connect();
}

void init(void)
{
	// SYSCLK = HFOSC0 = 24.5 MHz
	// SYSCLK = SYSCLK / 1
	CLKSEL = 0;
	// Timer 0/1 prescale SYSCLK / 4
	CKCON0 = 1;
	
	// cross-bar enable all pins
	XBR2 |= (1 << (6));
}

// temp. sensor I2C address
#define TMP100_ADR       0x48

// LED on P1.0
sbit LED = P1^0;

int main(void)
{
	int Temp;
	unsigned char TempH, TempL;

	unsigned short counter = 0;
	char ch, buffer[] = "-----";	// 4 decimal digits + CR terminal new line
	buffer[4] = 0x0D;							// CR terminal new line

	init();
	init_i2c0();
	init_uart0();

	while (1)
	{
		unsigned char idx = 0;

		// toggle LED
		LED ^= 1;

		I2C0_BUF_OUT[0] = 0x01;		// temp. sensor configuration register
		I2C0_BUF_OUT[1] = 0x60;		// %1100000 : TMP_R0=1 and TMP_R1=1 : 12-bit conversion
		I2C0_transfer_start(TMP100_ADR<<1, 2, 0);

		// start conversion
		I2C0_BUF_OUT[0] = 0x00;
		I2C0_transfer_start(TMP100_ADR<<1, 1, 0);

		// temp. sensor I2C address : read (2 bytes) : %1001000.1
		I2C0_transfer_start(TMP100_ADR<<1, 0, 2);
		
		TempH = I2C0_BUF_IN[0];		// high byte : 1-bit = 1°C
		TempL = I2C0_BUF_IN[1];		// low byte  : 1-bit = 0.0625°C

		Temp = TempH << 8;				// high byte
		Temp = Temp | TempL;			// low byte
		Temp = Temp >> 4;					// 12-bit resolution

		counter = (10*Temp)/16;		// scale : Temp*0.0625*10

		// convert to ASCII
		buffer[0] = 0x30 + (counter%1000)/100;
		buffer[1] = 0x30 + (counter%100)/10;
		buffer[2] = '.';
		buffer[3] = 0x30 + counter%10;

		while ((ch = buffer[idx++]) != 0)
			send(ch);
		
		delay(200);
	}
}
