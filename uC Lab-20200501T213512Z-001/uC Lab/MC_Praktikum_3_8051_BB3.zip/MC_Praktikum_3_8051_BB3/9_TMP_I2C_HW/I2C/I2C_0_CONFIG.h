#define  NUM_BYTES_WR   2
#define  NUM_BYTES_RD   2

extern idata unsigned char I2C0_BUF_OUT[NUM_BYTES_WR];
extern idata unsigned char I2C0_BUF_IN[NUM_BYTES_RD];

extern volatile bit transferInProgress;
extern volatile bit transferError;

void I2C0_transfer_start(unsigned char, unsigned char, unsigned char);
void I2C0_connect(void);
void I2C0_disconnect(void);
void I2C0_timeout(void);
