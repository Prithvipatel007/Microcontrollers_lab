#include "I2C/I2C_0.h"
#include "I2C/I2C_0_CONFIG.h"

// I2C write buffer
idata unsigned char I2C0_BUF_OUT[NUM_BYTES_WR];

// I2C read buffer
idata unsigned char I2C0_BUF_IN[NUM_BYTES_RD];

volatile bit transferInProgress = false;
volatile bit transferError = false;

/********************************************************************************/

void I2C0_transfer_start(unsigned char address, unsigned char write, unsigned char read)
{
	// clear I2C read buffer
	I2C0_BUF_IN[0] = 0;
	I2C0_BUF_IN[1] = 0;

	I2C0_transfer(address, I2C0_BUF_OUT, I2C0_BUF_IN, write, read);
	transferInProgress = true;
	while (transferInProgress);
}

/********************************************************************************/

void I2C0_connect(void)
{
	I2C0_reset();
	
	EIE1 |= (1 << (0));		// enable I2C0 irq
	
	I2C0_init(I2C0_TIMER0, true);
}

// I2C pins
sbit SDA = P2^0;
sbit SCL = P2^1;

void I2C0_disconnect(void)
{
	unsigned char idx;

	while (!SDA)
	{
		SCL = 0;
		for (idx=0; idx<255; idx++);
		SCL = 1;
		
		while (!SCL);		// Wait for open-drain
		
		for (idx=0; idx<10; idx++);
	}
}

/********************************************************************************/

// I2C timeout timer
void timer3(void) interrupt 14
{	
	TMR3CN0 &= ~TMR3CN0_TF3H__SET;		// Clear Timer 3 high overflow flag

	// Abort the transfer and set rx/tx bytes remaining to 0
	I2C0_abortTransfer();

	// Transfer is complete (error)
	transferInProgress = false;

	transferError = true;

	SMB0CF &= ~SMB0CF_ENSMB__ENABLED;	// Disable SMBus
	SMB0CF |= SMB0CF_ENSMB__ENABLED;	// Re-enable SMBus

	SMB0CN0_STA = 0;
}

void I2C0_timeout(void)
{
	TMR3RLH = 0x38;
	TMR3RLL = 0x9E;
	
	TMR3CN0 |= (1 << (2));		// Start Timer 3
	
	EIE1 |= (1 << (7));		// enable Timer 3 irq
}

/********************************************************************************/

void I2C0_transferCompleteCb()
{
	// Transfer is complete (success)
	transferInProgress = false;

	transferError = false;
}

void I2C0_errorCb (I2C0_TransferError_t error)
{
	error = error;
	
	// Abort the transfer
	I2C0_abortTransfer();
	// Transfer is complete (error)
	transferInProgress = false;

	transferError = true;
}

void I2C0_commandReceivedCb()
{
	// Not used
}
