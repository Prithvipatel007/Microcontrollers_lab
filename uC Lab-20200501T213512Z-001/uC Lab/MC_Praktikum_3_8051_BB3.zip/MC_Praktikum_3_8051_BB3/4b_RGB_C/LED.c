#include <REG51.h>
#include "EFM8BB3.h"

// default CLK = 24.5 MHz / 8 = 3 MHz
void delay(unsigned int cnt)
{
  while (--cnt);
	while (--cnt);
	while (--cnt);
	while (--cnt);
}

#define LED_R		1		// LED_R on P3.1
#define LED_G		0		// LED_G on P3.0
#define LED_B		2		// LED_B on P3.2

void main(void)
{
	XBR2 |= (1 << (6));	// port power
	
	// LEDs off
	P3 |= (1 << (LED_R));
	P3 |= (1 << (LED_G));
	P3 |= (1 << (LED_B));

  while (1)
  {
		// run LEDs
		P3 &= ~(1 << (LED_R));
		delay(200);
		P3 |= (1 << (LED_R));
		P3 &= ~(1 << (LED_G));
		delay(200);
		P3 |= (1 << (LED_G));
		P3 &= ~(1 << (LED_B));
		delay(200);
		P3 |= (1 << (LED_B));
  }
}
