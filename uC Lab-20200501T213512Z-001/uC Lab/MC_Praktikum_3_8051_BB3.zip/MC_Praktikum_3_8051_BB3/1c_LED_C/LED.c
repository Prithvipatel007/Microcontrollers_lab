#include <REG51.h>
#include "EFM8BB3.h"

// default CLK = 24.5 MHz / 8 = 3 MHz
void delay(unsigned int cnt)
{
  while (--cnt);
	while (--cnt);
	while (--cnt);
	while (--cnt);
}

sbit LED = P1^0;

void main(void)
{
	XBR2 |= (1 << (6));	// port power
	
	while (1)
  {
		LED ^= 1;					// toggle LED
		delay(200);
  }
}
