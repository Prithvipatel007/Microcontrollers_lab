sfr CLKSEL  = 0xA9;
sfr CKCON0  = 0x8E;

sfr P0MDOUT = 0xA4;
sfr P0MDIN  = 0xF1;
sfr P0SKIP  = 0xD4;

sfr P1SKIP  = 0xD5;

sfr ADC0MX  = 0xBB;
sfr ADC0CF0 = 0xBC;
sfr ADC0CF1 = 0xB9;
sfr ADC0CF2 = 0xDF;
sfr ADC0CN0 = 0xE8;
sfr ADC0CN1 = 0xB2;
sfr ADC0CN2 = 0xB3;
sfr ADC0L   = 0xBD;
sfr ADC0H   = 0xBE;

sfr EIE1    = 0xE6;

sfr XBR0    = 0xE1;
sfr XBR2    = 0xE3;
