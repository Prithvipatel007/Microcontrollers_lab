#include <REG51.h>
#include "EFM8BB3.h"

// default CLK = 24.5 MHz / 8 = 3 MHz
void delay(unsigned int cnt)
{
  while (--cnt);
	while (--cnt);
	while (--cnt);
	while (--cnt);
}

void main(void)
{
	XBR2 |= (1 << (6));	// port power
	
	while (1)
  {
		unsigned char n;
		
		// run LEDs from P1.0 to P1.7
		for (n=0; n<8; n++)
		{
			P1 = ~(1 << (n));
			delay(200);
		}
  }
}
