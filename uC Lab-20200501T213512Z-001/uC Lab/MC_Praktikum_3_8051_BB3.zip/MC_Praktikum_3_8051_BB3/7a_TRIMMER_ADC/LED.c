#include <REG51.h>
#include "EFM8BB3.h"

void delay(unsigned short cnt)
{
	while (--cnt)
	{
		volatile unsigned short idx;
		for (idx=0; idx<1000; idx++);
	}
}

void init(void)
{
	// SYSCLK = HFOSC0 = 24.5 MHz
	// SYSCLK = SYSCLK / 1
	CLKSEL = 0;

	// cross-bar enable all pins
	XBR2 |= (1 << (6));

	ADC0MX = 5;							// P0.7/ADC5
	ADC0CN1 = (1 << (6));		// ADC0 12-bit
	ADC0CF0 = (0x1 << (3));	// SYSCLK / (1 + 1)
	ADC0CF2 = (1 << (5));		// ADC0 voltage reference is VDD pin
	ADC0CN0 |= (1 << (7));	// ADC0 enable
}

void main (void)
{
	init();
	
	while (1)
	{
		unsigned short counter;
		
		// ADC0 conversion
		ADC0CN0 |= (1 << (4));					// start conversion
		while ((ADC0CN0 & 0x10) == 0);	// wait for done
		ADC0CN0 &= ~(1 << (5));					// reset
		
		counter = (ADC0H << 8) | ADC0L;	// 12-bit
		counter = counter >> 4;					// to 8-bit

		// display LEDs : max = 255
		P1 = 0xFF;
		P1 &= ~(1 << (0));
		if (counter > 35)
			P1 &= ~(1 << (1));
		if (counter > 70)
			P1 &= ~(1 << (2));
		if (counter > 105)
			P1 &= ~(1 << (3));
		if (counter > 140)
			P1 &= ~(1 << (4));
		if (counter > 175)
			P1 &= ~(1 << (5));
		if (counter > 210)
			P1 &= ~(1 << (6));
		if (counter > 245)
			P1 &= ~(1 << (7));

		delay(50);
	}
}
